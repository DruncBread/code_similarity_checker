flag = 1

if flag == 1 and len(flag2) == 1:
    pass

if flag == 1:
    test = 1

if flag == 1:
    flag = 2
else:
    flag = 3

test = "Over"
