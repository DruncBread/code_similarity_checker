booo = 1

if booo == 1 and len(flag2) == 1:
    pass

if booo == 1:
    heihei = 1

if booo == 1:
    booo = 2
else:
    booo = 3

heihei = "Over"
